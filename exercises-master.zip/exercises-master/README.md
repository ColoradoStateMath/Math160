# exercises

Contains exercises for calculus courses. All the APEX, MSLC, and Sample Midterm problems 
were typed up by Matthew Carr.

# Some helpful commands?

ls quadraticRationalFunctionLimits/*.tex | awk '{printf "\\activity{%s}\n", $1}' > inputs.tex
